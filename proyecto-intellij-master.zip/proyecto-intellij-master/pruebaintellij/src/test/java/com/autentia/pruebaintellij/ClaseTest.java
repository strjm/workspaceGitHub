package com.autentia.pruebaintellij;

public class ClaseTest {
	
}