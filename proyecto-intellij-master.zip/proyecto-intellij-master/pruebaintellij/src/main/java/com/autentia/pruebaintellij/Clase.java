package com.autentia.pruebaintellij;

public class Clase {
	
	
}
